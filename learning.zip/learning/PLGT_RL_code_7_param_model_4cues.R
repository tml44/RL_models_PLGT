# clear 
rm(list=ls())

# install Rsolnp package if you do not have it
# install.packages("Rsolnp")
library(Rsolnp)

# import the data
setwd("/mnt/data/PLGT_ALC/RL")#please set the working directory where the data file is located.
data <- read.csv("stim_choice_return_4_cues.csv",header = T)

savepathfig <- "/mnt/data/PLGT_ALC/RL/figs_goprob/4cues/"
dir.create(savepathfig)
savepathgoprob <- "/mnt/data/PLGT_ALC/RL/params/goprob_4cues/"
dir.create(savepathgoprob)
savepathlearningrates <- "/mnt/data/PLGT_ALC/RL/params/learning_rates_4cues/"
dir.create(savepathlearningrates)

n <- length(unique(data$Subject))
trial <- numeric(n)
choice_all<- matrix(0, nrow = n, ncol = max(data$trial))
result_all <- choice_all
stimuli_all <- choice_all

for(i in 1:n){
  trial[i] <- max(data$trial[data$Subject == i])
  choice_all[i,1:trial[i]] <- data$choice[data$Subject == i]
  result_all[i,1:trial[i]] <- data$return[data$Subject == i]
  stimuli_all[i,1:trial[i]] <- data$stimulus[data$Subject == i]
}

# exclude the data
# ex <- c(2,48,52)
# choice_all <- choice_all[-ex,]
# result_all <- result_all[-ex,]
# stimuli_all <- stimuli_all[-ex,]
# n <- n-length(ex)
#PP <- PP[-ex]
#SP <- SP[-ex]
#Anx <- Anx[-ex]

LL <- matrix(0,nrow = n,ncol = 50)
Epsilon_RP <- LL# RP = Reward-Positive prediction error
Epsilon_RN <- LL# RN = Reward-Negative prediction error
Epsilon_PP <- LL# PP = Punishment-Positive prediction error
Epsilon_PN <- LL# PN = Punishment-Negative prediction error
Rho <- LL
Bias <- LL
Pavlov <- LL
hesseERP <- LL
hesseERN <- LL
hesseEPP <- LL
hesseEPN <- LL
hesseR <- LL
hesseB <- LL
hesseP <- LL
sampling <- matrix(0,nrow = n,ncol=1000)
E4PB_probability <- numeric(n)
n_param <- 7# the number of free parameters in this model
s <- 4# the number of stimuli(i.e., images)

f_learn = function(param,choice,result,stimuli,trial,n,s){
  epsilon_RP <- 1/(1+exp(-param[1]))
  epsilon_RN <- 1/(1+exp(-param[2]))
  epsilon_PP <- 1/(1+exp(-param[3]))
  epsilon_PN <- 1/(1+exp(-param[4]))
  rho <- exp(param[5])
  b <- param[6]
  pav <-exp(param[7])
  choice <- choice
  result <- result
  stimuli <- stimuli
  st <- result > 0 # return a boolean vector that represents the trial number where the reward is appeared.
  trial <- trial
  Pgo <- numeric(trial)
  ll <- 0
  Q <- matrix(0, nrow = s*2, ncol = trial)
  V <- matrix(0, nrow = s, ncol = trial)
  for (t in 1:trial){
    Pgo[t] <- exp(Q[stimuli[t]+s,t]+pav*V[stimuli[t],t]+b)/(exp(Q[stimuli[t]+s,t]+pav*V[stimuli[t],t]+b) + exp(Q[stimuli[t],t]))
    ll <- ll + (choice[t] == s) * log(Pgo[t]) + (choice[t] == 0) * log(1-Pgo[t])
    if (t < trial){
      Q[,t+1] <- Q[,t]
      V[,t+1] <- V[,t]
      delta <- rho * result[t] - Q[stimuli[t]+choice[t],t+1]
      if(any(st[stimuli == stimuli[t]])){#return true if the reward on a stimulus at trial t is appeared somewhere. 
        if(delta > 0){
          Q[stimuli[t]+choice[t],t+1]  <- Q[stimuli[t]+choice[t],t] + epsilon_RP * delta
          V[stimuli[t],t+1]  <- V[stimuli[t],t] + epsilon_RP * (rho * result[t] - V[stimuli[t],t])
        }
        else{
          Q[stimuli[t]+choice[t],t+1]  <- Q[stimuli[t]+choice[t],t] + epsilon_RN * delta
          V[stimuli[t],t+1]  <- V[stimuli[t],t] + epsilon_RN * (rho * result[t] - V[stimuli[t],t])
        }
      }
      else{
        if(delta > 0){
          Q[stimuli[t]+choice[t],t+1]  <- Q[stimuli[t]+choice[t],t] + epsilon_PP * delta
          V[stimuli[t],t+1]  <- V[stimuli[t],t] + epsilon_PP * (rho * result[t] - V[stimuli[t],t])
        }
        else{
          Q[stimuli[t]+choice[t],t+1]  <- Q[stimuli[t]+choice[t],t] + epsilon_PN * delta
          V[stimuli[t],t+1]  <- V[stimuli[t],t] + epsilon_PN * (rho * result[t] - V[stimuli[t],t])
        }
      }
    }
  }
  return(list(negll = -ll, Q = Q, Pgo = Pgo))
}
f_minimize = function(param,choice,result,stimuli,trial,n,s){
  results = f_learn(param,choice,result,stimuli,trial,n,s)
  return(results$negll)
}

for (idx in 1:n){
  fvalmin = Inf;
  for(i in 1:20){
    initial_param <- runif(n_param,0,1.0)
    analyze <- solnp(initial_param,f_minimize,UB=c(20,20,20,20,3,Inf,3),choice = choice_all[idx,], result = result_all[idx,], stimuli = stimuli_all[idx,],trial = trial[idx], n = n,s = s)
    if (analyze$values[analyze$outer.iter+1] < fvalmin){
      LL[idx,1] <- fvalmin <- analyze$values[analyze$outer.iter+1]
      Epsilon_RP[idx,1] <- analyze$pars[1]
      Epsilon_RN[idx,1] <- analyze$pars[2]
      Epsilon_PP[idx,1] <- analyze$pars[3]
      Epsilon_PN[idx,1] <- analyze$pars[4]
      Rho[idx,1] <- analyze$pars[5]
      Bias[idx,1] <- analyze$pars[6]
      Pavlov[idx,1] <- analyze$pars[7]
      #to calculate the variance of the parameter distribution, we extract the diagonal component of the inverse matrix of hessian
      hesseERP[idx,1] <- diag(solve(analyze$hessian))[1]
      hesseERN[idx,1] <- diag(solve(analyze$hessian))[2]
      hesseEPP[idx,1] <- diag(solve(analyze$hessian))[3]
      hesseEPN[idx,1] <- diag(solve(analyze$hessian))[4]
      hesseR[idx,1] <- diag(solve(analyze$hessian))[5]
      hesseB[idx,1] <- diag(solve(analyze$hessian))[6]
      hesseP[idx,1] <- diag(solve(analyze$hessian))[7]
    }
  }
}

# maximum likelihood estimates
EPSILON_RP <- 1/(1+exp(-Epsilon_RP[,1]))
EPSILON_RN <- 1/(1+exp(-Epsilon_RN[,1]))
EPSILON_PP <- 1/(1+exp(-Epsilon_PP[,1]))
EPSILON_PN <- 1/(1+exp(-Epsilon_PN[,1]))
RHO <- exp(Rho[,1])
BIAS <- Bias[,1]
PAVLOV <- exp(Pavlov[,1])
LL_E4PB <- LL[,1]#sum(2*LL_E4PB + n_param*log(sum(trial)))

f_plot = function(id,im,x = 1){#id = participants'ID; im = image, x = set the parameters in x th iteration in the EM-algorithm (x is set to 1 by default).
  prob <- f_learn(c(Epsilon_RP[id,x],Epsilon_RN[id,x],Epsilon_PP[id,x],Epsilon_PN[id,x],Rho[id,x],Bias[id,x],Pavlov[id,x]),choice_all[id,],result_all[id,],stimuli_all[id,],trial[id],n,s)$Pgo
  c_I <- choice_all[id,1:trial[id]][stimuli_all[id,1:trial[id]] == im]/s
  r_I <- 1+abs(result_all[id,1:trial[id]][stimuli_all[id,1:trial[id]] == im])
  t_I <- 1:sum(stimuli_all[id,1:trial[id]]==im)
  plot(t_I,prob[stimuli_all[id,1:trial[id]]==im], type = "l",ylim = c(0.0,1.1),xlab = "trial",ylab = "p(go)")
  par(new =T)
  plot(t_I,c_I,ylim = c(0.0,1.1),col = r_I,ann = F)
}
#The line indicates the probabilities the model predicted. 
#The circles indicate participants'choices: 1 = go, 0 = no-go.
#The color of the circle indicates whether the outcome appeared: red = present, black = absent.
m <- length(unique(data$stimulus))
for(i1 in 1:n){
  for(j1 in 1:m){
    f_plot(i1,j1) #show the plot of the data for the ID number i in image j
    # filename = paste0(mypath,paste("subject",i,"_image",j,".pdf",sep = ""))
    # dev.print(pdf, filename)
    # subject <- data$ID == i
    subjectid <- data$ID[data$Subject == i1]
    filename1 = paste0(savepathfig,paste(subjectid[1],"_image",j1,".jpg",sep = ""))
    dev.copy(jpeg,filename1, units="in", width=5, height=5, res=300);
    dev.off ();
  }
}

# save go probabilities
for(i2 in 1:n){
  for(j2 in 1:m){
    id = i2
    x = 1
    im = j2
    prob <- f_learn(c(Epsilon_RP[id,x],Epsilon_RN[id,x],Epsilon_PP[id,x],Epsilon_PN[id,x],Rho[id,x],Bias[id,x],Pavlov[id,x]),choice_all[id,],result_all[id,],stimuli_all[id,],trial[id],n,s)$Pgo
    stimprob <- prob[stimuli_all[id,1:trial[id]]==im]
    subjectid <- data$ID[data$Subject == i2]
    filename2 = paste0(savepathgoprob,paste(subjectid[1],"_image",j2,".csv",sep = ""))
    savedata1 <- data.frame(stimprob)
    write.csv(savedata1, filename2)
    filename3 = paste0(savepathgoprob,paste(subjectid[1],"_all.csv",sep = ""))
    savedata2 <- data.frame(prob)
    write.csv(savedata2, filename3)
  }
}
 
# estimate hyper parameters of the posterior distributions
EpsilonRP_mu <- mean(Epsilon_RP[,1])
EpsilonRP_sigma <- sum(Epsilon_RP[,1]^2 + hesseERP[,1])/n - EpsilonRP_mu^2
EpsilonRN_mu <- mean(Epsilon_RN[,1])
EpsilonRN_sigma <- sum(Epsilon_RN[,1]^2 + hesseERN[,1])/n - EpsilonRN_mu^2
EpsilonPP_mu <- mean(Epsilon_PP[,1])
EpsilonPP_sigma <- sum(Epsilon_PP[,1]^2 + hesseEPP[,1])/n - EpsilonPP_mu^2
EpsilonPN_mu <- mean(Epsilon_PN[,1])
EpsilonPN_sigma <- sum(Epsilon_PN[,1]^2 + hesseEPN[,1])/n - EpsilonPN_mu^2
Rho_mu <- mean(Rho[,1])
Rho_sigma <- sum(Rho[,1]^2 + hesseR[,1])/n - Rho_mu^2
Bias_mu <- mean(Bias[,1])
Bias_sigma <- sum(Bias[,1]^2 + hesseB[,1])/n - Bias_mu^2
Pavlov_mu <- mean(Pavlov[,1])
Pavlov_sigma <- sum(Pavlov[,1]^2 + hesseP[,1])/n - Pavlov_mu^2
# calculate the convergence criterion
QERP <- -(n*log(2*pi*EpsilonRP_sigma))/2-sum((Epsilon_RP[,1]^2 + hesseERP[,1] - 2*Epsilon_RP[,1]*EpsilonRP_mu + EpsilonRP_mu^2)/(2*EpsilonRP_sigma))
QERN <- -(n*log(2*pi*EpsilonRN_sigma))/2-sum((Epsilon_RN[,1]^2 + hesseERN[,1] - 2*Epsilon_RN[,1]*EpsilonRN_mu + EpsilonRN_mu^2)/(2*EpsilonRN_sigma))
QEPP <- -(n*log(2*pi*EpsilonPP_sigma))/2-sum((Epsilon_PP[,1]^2 + hesseEPP[,1] - 2*Epsilon_PP[,1]*EpsilonPP_mu + EpsilonPP_mu^2)/(2*EpsilonPP_sigma))
QEPN <- -(n*log(2*pi*EpsilonPN_sigma))/2-sum((Epsilon_PN[,1]^2 + hesseEPN[,1] - 2*Epsilon_PN[,1]*EpsilonPN_mu + EpsilonPN_mu^2)/(2*EpsilonPN_sigma))
QR <- -(n*log(2*pi*Rho_sigma))/2-sum((Rho[,1]^2 + hesseR[,1] - 2*Rho[,1]*Rho_mu + Rho_mu^2)/(2*Rho_sigma))
QB <- -(n*log(2*pi*Bias_sigma))/2-sum((Bias[,1]^2 + hesseB[,1] - 2*Bias[,1]*Bias_mu + Bias_mu^2)/(2*Bias_sigma))
QP <- -(n*log(2*pi*Pavlov_sigma))/2-sum((Pavlov[,1]^2 + hesseP[,1] - 2*Pavlov[,1]*Pavlov_mu + Pavlov_mu^2)/(2*Pavlov_sigma))
Q_value <- numeric(50)
Q_value[1] <- QERP + QERN + QEPP + QEPN + QR + QB + QP

f_Q = function(param, choice, result, stimuli, trial, n, s){
  epsilon_RP <- 1/(1+exp(-param[1]))
  epsilon_RN <- 1/(1+exp(-param[2]))
  epsilon_PP <- 1/(1+exp(-param[3]))
  epsilon_PN <- 1/(1+exp(-param[4]))
  rho <- exp(param[5])
  b <- param[6]
  pav <-exp(param[7])
  choice <- choice
  result <- result
  stimuli <- stimuli
  st <- result > 0 
  trial <- trial
  Pgo <- numeric(trial)
  ll <- 0
  Q <- matrix(0, nrow = s*2, ncol = trial)
  V <- matrix(0, nrow = s, ncol = trial)
  for (t in 1:trial){
    Pgo[t] <- exp(Q[stimuli[t]+s,t]+pav*V[stimuli[t],t]+b)/(exp(Q[stimuli[t]+s,t]+pav*V[stimuli[t],t]+b) + exp(Q[stimuli[t],t]))
    ll <- ll + (choice[t] == s) * log(Pgo[t]) + (choice[t] == 0) * log(1-Pgo[t])
    if (t < trial){
      Q[,t+1] <- Q[,t]
      V[,t+1] <- V[,t]
      delta <- rho * result[t] - Q[stimuli[t]+choice[t],t+1]
      if(any(st[stimuli == stimuli[t]])){
        if(delta > 0){
          Q[stimuli[t]+choice[t],t+1]  <- Q[stimuli[t]+choice[t],t] + epsilon_RP * delta
          V[stimuli[t],t+1]  <- V[stimuli[t],t] + epsilon_RP * (rho * result[t] - V[stimuli[t],t])
        }
        else{
          Q[stimuli[t]+choice[t],t+1]  <- Q[stimuli[t]+choice[t],t] + epsilon_RN * delta
          V[stimuli[t],t+1]  <- V[stimuli[t],t] + epsilon_RN * (rho * result[t] - V[stimuli[t],t])
        }
      }
      else{
        if(delta > 0){
          Q[stimuli[t]+choice[t],t+1]  <- Q[stimuli[t]+choice[t],t] + epsilon_PP * delta
          V[stimuli[t],t+1]  <- V[stimuli[t],t] + epsilon_PP * (rho * result[t] - V[stimuli[t],t])
        }
        else{
          Q[stimuli[t]+choice[t],t+1]  <- Q[stimuli[t]+choice[t],t] + epsilon_PN * delta
          V[stimuli[t],t+1]  <- V[stimuli[t],t] + epsilon_PN * (rho * result[t] - V[stimuli[t],t])
        }
      }
    }
  }
  ll <- ll+ log(dnorm(param[1],EpsilonRP_mu,sqrt(EpsilonRP_sigma))) + log(dnorm(param[2],EpsilonRN_mu,sqrt(EpsilonRN_sigma))) + log(dnorm(param[3],EpsilonPP_mu,sqrt(EpsilonPP_sigma))) + log(dnorm(param[4],EpsilonPN_mu,sqrt(EpsilonPN_sigma)))+log(dnorm(param[5],Rho_mu,sqrt(Rho_sigma)))+log(dnorm(param[6],Bias_mu,sqrt(Bias_sigma)))+log(dnorm(param[7],Pavlov_mu,sqrt(Pavlov_sigma)))
  return(negll = -ll)
}

for(x in 2:length(Q_value)){
  for (idx in 1:n){
    fvalmin = Inf;
    for(i in 1:10){
      initial_param <- runif(n_param,0,1.0)
      analyze <- solnp(initial_param,f_Q,UB=c(20,20,20,20,3,Inf,3),choice = choice_all[idx,], result = result_all[idx,], stimuli = stimuli_all[idx,], trial = trial[idx], n = n, s = s)#
      if (analyze$values[analyze$outer.iter+1] < fvalmin){
        LL[idx,x] <- fvalmin <- analyze$values[analyze$outer.iter+1]
        Epsilon_RP[idx,x] <- analyze$pars[1]
        Epsilon_RN[idx,x] <- analyze$pars[2]
        Epsilon_PP[idx,x] <- analyze$pars[3]
        Epsilon_PN[idx,x] <- analyze$pars[4]
        Rho[idx,x] <- analyze$pars[5]
        Bias[idx,x] <- analyze$pars[6]
        Pavlov[idx,x] <- analyze$pars[7]
        #to calculate the variance of the parameter distribution, we extract the diagonal component of the inverse matrix of hessian
        hesseERP[idx,x] <- diag(solve(analyze$hessian))[1]
        hesseERN[idx,x] <- diag(solve(analyze$hessian))[2]
        hesseEPP[idx,x] <- diag(solve(analyze$hessian))[3]
        hesseEPN[idx,x] <- diag(solve(analyze$hessian))[4]
        hesseR[idx,x] <- diag(solve(analyze$hessian))[5]
        hesseB[idx,x] <- diag(solve(analyze$hessian))[6]
        hesseP[idx,x] <- diag(solve(analyze$hessian))[7]
      }
    }
  }
  EpsilonRP_mu <- mean(Epsilon_RP[,x])
  EpsilonRP_sigma <- sum(Epsilon_RP[,x]^2 + hesseERP[,x])/n - EpsilonRP_mu^2
  EpsilonRN_mu <- mean(Epsilon_RN[,x])
  EpsilonRN_sigma <- sum(Epsilon_RN[,x]^2 + hesseERN[,x])/n - EpsilonRN_mu^2
  EpsilonPP_mu <- mean(Epsilon_PP[,x])
  EpsilonPP_sigma <- sum(Epsilon_PP[,x]^2 + hesseEPP[,x])/n - EpsilonPP_mu^2
  EpsilonPN_mu <- mean(Epsilon_PN[,x])
  EpsilonPN_sigma <- sum(Epsilon_PN[,x]^2 + hesseEPN[,x])/n - EpsilonPN_mu^2
  Rho_mu <- mean(Rho[,x])
  Rho_sigma <- sum(Rho[,x]^2 + hesseR[,x])/n - Rho_mu^2
  Bias_mu <- mean(Bias[,x])
  Bias_sigma <- sum(Bias[,x]^2 + hesseB[,x])/n - Bias_mu^2
  Pavlov_mu <- mean(Pavlov[,x])
  Pavlov_sigma <- sum(Pavlov[,x]^2 + hesseP[,x])/n - Pavlov_mu^2
  QERP <- -(n*log(2*pi*EpsilonRP_sigma))/2-sum((Epsilon_RP[,x]^2 + hesseERP[,x] - 2*Epsilon_RP[,x]*EpsilonRP_mu + EpsilonRP_mu^2)/(2*EpsilonRP_sigma))
  QERN <- -(n*log(2*pi*EpsilonRN_sigma))/2-sum((Epsilon_RN[,x]^2 + hesseERN[,x] - 2*Epsilon_RN[,x]*EpsilonRN_mu + EpsilonRN_mu^2)/(2*EpsilonRN_sigma))
  QEPP <- -(n*log(2*pi*EpsilonPP_sigma))/2-sum((Epsilon_PP[,x]^2 + hesseEPP[,x] - 2*Epsilon_PP[,x]*EpsilonPP_mu + EpsilonPP_mu^2)/(2*EpsilonPP_sigma))
  QEPN <- -(n*log(2*pi*EpsilonPN_sigma))/2-sum((Epsilon_PN[,x]^2 + hesseEPN[,x] - 2*Epsilon_PN[,x]*EpsilonPN_mu + EpsilonPN_mu^2)/(2*EpsilonPN_sigma))
  QR <- -(n*log(2*pi*Rho_sigma))/2-sum((Rho[,x]^2 + hesseR[,x] - 2*Rho[,x]*Rho_mu + Rho_mu^2)/(2*Rho_sigma))
  QB <- -(n*log(2*pi*Bias_sigma))/2-sum((Bias[,x]^2 + hesseB[,x] - 2*Bias[,x]*Bias_mu + Bias_mu^2)/(2*Bias_sigma))
  QP <- -(n*log(2*pi*Pavlov_sigma))/2-sum((Pavlov[,x]^2 + hesseP[,x] - 2*Pavlov[,x]*Pavlov_mu + Pavlov_mu^2)/(2*Pavlov_sigma))
  Q_value[x] <- QERP + QERN + QEPP + QEPN + QR + QB + QP
  if(abs(Q_value[x] - Q_value[x-1]) < 0.01) break
}

Ep_RP <- 1/(1+exp(-Epsilon_RP[,x]))
Ep_RN <- 1/(1+exp(-Epsilon_RN[,x]))
Ep_PP <- 1/(1+exp(-Epsilon_PP[,x]))
Ep_PN <- 1/(1+exp(-Epsilon_PN[,x]))
Rh <- exp(Rho[,x])
Bi <- Bias[,x]
Pav <-exp(Pavlov[,x])

# calculate iBIC value
for (idx in 1:n){
  for (k in 1:1000){
    epsilonRP_k <- rnorm(1,EpsilonRP_mu,sqrt(EpsilonRP_sigma))
    epsilonRN_k <- rnorm(1,EpsilonRN_mu,sqrt(EpsilonRN_sigma))
    epsilonPP_k <- rnorm(1,EpsilonPP_mu,sqrt(EpsilonPP_sigma))
    epsilonPN_k <- rnorm(1,EpsilonPN_mu,sqrt(EpsilonPN_sigma))
    rho_k <- rnorm(1,Rho_mu,sqrt(Rho_sigma))
    bias_k <- rnorm(1,Bias_mu,sqrt(Bias_sigma))
    pav_k <- rnorm(1,Pavlov_mu,sqrt(Pavlov_sigma))
    sampling[idx,k] <- f_minimize(c(epsilonRP_k,epsilonRN_k,epsilonPP_k,epsilonPN_k,rho_k,bias_k,pav_k),choice_all[idx,],result_all[idx,],stimuli_all[idx,],trial[idx],n,s)
    if(is.nan(sampling[idx,k])){
      while(is.nan(sampling[idx,k])){
        epsilonRP_k <- rnorm(1,EpsilonRP_mu,sqrt(EpsilonRP_sigma))
        epsilonRN_k <- rnorm(1,EpsilonRN_mu,sqrt(EpsilonRN_sigma))
        epsilonPP_k <- rnorm(1,EpsilonPP_mu,sqrt(EpsilonPP_sigma))
        epsilonPN_k <- rnorm(1,EpsilonPN_mu,sqrt(EpsilonPN_sigma))
        rho_k <- rnorm(1,Rho_mu,sqrt(Rho_sigma))
        bias_k <- rnorm(1,Bias_mu,sqrt(Bias_sigma))
        pav_k <- rnorm(1,Pavlov_mu,sqrt(Pavlov_sigma))
        sampling[idx,k] <- f_minimize(c(epsilonRP_k,epsilonRN_k,epsilonPP_k,epsilonPN_k,rho_k,bias_k,pav_k),choice_all[idx,],result_all[idx,],stimuli_all[idx,],trial[idx],n,s)
      }
    }
    if(is.infinite(sampling[idx,k])){
      epsilonRP_k <- rnorm(1,EpsilonRP_mu,sqrt(EpsilonRP_sigma))
      epsilonRN_k <- rnorm(1,EpsilonRN_mu,sqrt(EpsilonRN_sigma))
      epsilonPP_k <- rnorm(1,EpsilonPP_mu,sqrt(EpsilonPP_sigma))
      epsilonPN_k <- rnorm(1,EpsilonPN_mu,sqrt(EpsilonPN_sigma))
      rho_k <- rnorm(1,Rho_mu,sqrt(Rho_sigma))
      bias_k <- rnorm(1,Bias_mu,sqrt(Bias_sigma))
      pav_k <- rnorm(1,Pavlov_mu,sqrt(Pavlov_sigma))
      sampling[idx,k] <- f_minimize(c(epsilonRP_k,epsilonRN_k,epsilonPP_k,epsilonPN_k,rho_k,bias_k,pav_k),choice_all[idx,],result_all[idx,],stimuli_all[idx,],trial[idx],n,s)
    }
  }
  E4PB_probability[idx] <- log(sum(exp(-sampling[idx,]))/1000)#log(mean(exp(-sampling[idx,])))
}

# The penalty term for the number of free parameter is twice the number of free parameters, because we used the mean and variance of each free parameter
iBIC_E4PB <- -2*sum(E4PB_probability)+n_param*2*log(sum(trial))

# save model outputs
filename4 = paste0(savepathlearningrates,paste("learning_rates.csv",sep = ""))
IDs = unique(data$ID)
savedata_params <- data.frame(IDs,EPSILON_RP,EPSILON_RN,EPSILON_PP,EPSILON_PN)
write.csv(savedata_params, filename4) # , row.names=FALSE
