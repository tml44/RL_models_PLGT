# clear 
rm(list=ls())

# install Rsolnp package if you do not have it
# install.packages("Rsolnp")
library(Rsolnp)
library(MASS)# MASS is a default package for R and includes the "ginv" function for computing inverse matrix.

# import the data
subj_version = 'S62'
setwd("/mnt/data/PLGT_ALC/RL")#please set the working directory where the data file is located.
mainfile = paste("stim_choice_return_learning_",subj_version,".csv",sep = "")
data <- read.csv(mainfile ,header = T)
n <- length(unique(data$Subject))
trial <- numeric(n)
choice_all<- matrix(0, nrow = n, ncol = max(data$trial))
result_all <- choice_all
stimuli_all <- choice_all

for(i in 1:n){
  trial[i] <- max(data$trial[data$Subject == i])
  choice_all[i,1:trial[i]] <- data$choice[data$Subject == i]
  result_all[i,1:trial[i]] <- data$return[data$Subject == i]
  stimuli_all[i,1:trial[i]] <- data$stimulus[data$Subject == i]
}

# exclude the data
#ex <- c()
#choice_all <- choice_all[-ex,]
#result_all <- result_all[-ex,]
#stimuli_all <- stimuli_all[-ex,]
#n <- n-length(ex)

LL <- matrix(0,nrow = n,ncol = 50)
Epsilon_P <- LL
Epsilon_N <- LL
Rho <- LL
hesseEP <- LL
hesseEN <- LL
hesseR <- LL
sampling <- matrix(0,nrow = n,ncol=1000)
E2_probability <- numeric(n)
n_param <- 3# the number of free parameters in this model
s <- 8# the number of stimuli(i.e., images)

f_learn = function(param,choice,result,stimuli,trial,s){
  epsilon_P <- 1/(1+exp(-param[1]))
  epsilon_N <- 1/(1+exp(-param[2]))
  rho <- exp(param[3])
  choice <- choice
  result <- result
  stimuli <- stimuli
  trial <- trial
  Pgo <- numeric(trial)
  ll <- 0
  Q <- matrix(0, nrow = s*2, ncol = trial)
  for (t in 1:trial){
    Pgo[t] <- exp(Q[stimuli[t]+s,t])/(exp(Q[stimuli[t]+s,t]) + exp(Q[stimuli[t],t]))
    ll <- ll + (choice[t] == s) * log(Pgo[t]) + (choice[t] == 0) * log(1-Pgo[t])
    if (t < trial){
      Q[,t+1] <- Q[,t]
      delta <- rho * result[t] - Q[stimuli[t]+choice[t],t]
      if(delta > 0){Q[stimuli[t]+choice[t],t+1]  <- Q[stimuli[t]+choice[t],t] + epsilon_P * delta}
      else{Q[stimuli[t]+choice[t],t+1]  <- Q[stimuli[t]+choice[t],t] + epsilon_N * delta}
    }
  }
  return(list(negll = -ll, Q = Q, Pgo = Pgo))
}
f_minimize = function(param,choice,result,stimuli,trial,s){
  results = f_learn(param,choice,result,stimuli,trial,s)
  return(results$negll)
}

for (idx in 1:n){
  fvalmin = Inf;
  for(i in 1:10){
    initial_param <- runif(n_param,0,1.0)
    analyze <- solnp(initial_param,f_minimize,UB=c(20,20,3),choice = choice_all[idx,], result = result_all[idx,], stimuli = stimuli_all[idx,],trial = trial[idx], s = s)
    if (analyze$values[analyze$outer.iter+1] < fvalmin){
      LL[idx,1] <- fvalmin <- analyze$values[analyze$outer.iter+1]
      Epsilon_P[idx,1] <- analyze$pars[1]
      Epsilon_N[idx,1] <- analyze$pars[2]
      Rho[idx,1] <- analyze$pars[3]
      #to calculate the variance of the parameter distribution, we extract the diagonal component of the inverse matrix of hessian
      hesseEP[idx,1] <- diag(ginv(analyze$hessian))[1]
      hesseEN[idx,1] <- diag(ginv(analyze$hessian))[2]
      hesseR[idx,1] <- diag(ginv(analyze$hessian))[3]
    }
  }
}

# maximum likelihood estimates
EPSILON_P <- 1/(1+exp(-Epsilon_P[,1]))
EPSILON_N <- 1/(1+exp(-Epsilon_N[,1]))
RHO <- exp(Rho[,1])
LL_E2 <- LL[,1]#sum(2*LL_E2 + n_param*log(trial))

f_plot = function(id,im,x = 1){#id = participants'ID; im = image, x = set the parameters in x th iteration in the EM-algorithm (x is set to 1 by default).
  prob <- f_learn(c(Epsilon_P[id,x],Epsilon_N[id,x],Rho[id,x]),choice_all[id,],result_all[id,],stimuli_all[id,],trial[id],s)$Pgo
  c_I <- choice_all[id,1:trial[id]][stimuli_all[id,1:trial[id]] == im]/s
  r_I <- 1+abs(result_all[id,1:trial[id]][stimuli_all[id,1:trial[id]] == im])
  t_I <- 1:sum(stimuli_all[id,1:trial[id]]==im)
  plot(t_I,prob[stimuli_all[id,1:trial[id]]==im], type = "l",ylim = c(0.0,1.1),xlab = "trial",ylab = "p(go)")
  par(new =T)
  plot(t_I,c_I,ylim = c(0.0,1.1),col = r_I,ann = F)
}
#show the plot of the data for the ID number 1 in image 1
f_plot(1,1)
#The line indicates the probabilities the model predicted. 
#The circles indicate participants'choices: 1 = go, 0 = no-go.
#The color of the circle indicates whether the outcome appeared: red = present, black = absent.


# estimate hyper parameters of the posterior distribitions
EpsilonP_mu <- mean(Epsilon_P[,1])
EpsilonP_sigma <- sum(Epsilon_P[,1]^2 + hesseEP[,1])/n - EpsilonP_mu^2
EpsilonN_mu <- mean(Epsilon_N[,1])
EpsilonN_sigma <- sum(Epsilon_N[,1]^2 + hesseEN[,1])/n - EpsilonN_mu^2
Rho_mu <- mean(Rho[,1])
Rho_sigma <- sum(Rho[,1]^2 + hesseR[,1])/n - Rho_mu^2
# calculate the convergence criterion
QEP <- -(n*log(2*pi*EpsilonP_sigma))/2-sum((Epsilon_P[,1]^2 + hesseEP[,1] - 2*Epsilon_P[,1]*EpsilonP_mu + EpsilonP_mu^2)/(2*EpsilonP_sigma))
QEN <- -(n*log(2*pi*EpsilonN_sigma))/2-sum((Epsilon_N[,1]^2 + hesseEN[,1] - 2*Epsilon_N[,1]*EpsilonN_mu + EpsilonN_mu^2)/(2*EpsilonN_sigma))
QR <- -(n*log(2*pi*Rho_sigma))/2-sum((Rho[,1]^2 + hesseR[,1] - 2*Rho[,1]*Rho_mu + Rho_mu^2)/(2*Rho_sigma))
Q_value <- numeric(50)
Q_value[1] <- QEP + QEN + QR

f_Q = function(param, choice, result, stimuli, trial, s){
  epsilon_P <- 1/(1+exp(-param[1]))
  epsilon_N <- 1/(1+exp(-param[2]))
  rho <- exp(param[3])
  choice <- choice
  result <- result
  stimuli <- stimuli
  trial <- trial
  Pgo <- numeric(trial)
  ll <- 0
  Q <- matrix(0, nrow = s*2, ncol = trial)
  for (t in 1:trial){
    Pgo[t] <- exp(Q[stimuli[t]+s,t])/(exp(Q[stimuli[t]+s,t]) + exp(Q[stimuli[t],t]))
    ll <- ll + (choice[t] == s) * log(Pgo[t]) + (choice[t] == 0) * log(1-Pgo[t])
    if (t < trial){
      Q[,t+1] <- Q[,t]
      delta <- rho * result[t] - Q[stimuli[t]+choice[t],t]
      if(delta > 0){Q[stimuli[t]+choice[t],t+1]  <- Q[stimuli[t]+choice[t],t] + epsilon_P * delta}
      else{Q[stimuli[t]+choice[t],t+1]  <- Q[stimuli[t]+choice[t],t] + epsilon_N * delta}
    }
  }
  ll <- ll+log(dnorm(param[1],EpsilonP_mu,sqrt(EpsilonP_sigma)))+log(dnorm(param[2],EpsilonN_mu,sqrt(EpsilonN_sigma)))+log(dnorm(param[3],Rho_mu,sqrt(Rho_sigma)))
  return(negll = -ll)
}

for(x in 2:length(Q_value)){
  for (idx in 1:n){
    fvalmin = Inf;
    for(i in 1:10){
      initial_param <- runif(n_param,0,1.0)
      analyze <- solnp(initial_param,f_Q,UB=c(20,20,3),choice = choice_all[idx,], result = result_all[idx,], stimuli = stimuli_all[idx,], trial = trial[idx] , s = s)#
      if (analyze$values[analyze$outer.iter+1] < fvalmin){
        LL[idx,x] <- fvalmin <- analyze$values[analyze$outer.iter+1]
        Epsilon_P[idx,x] <- analyze$pars[1]
        Epsilon_N[idx,x] <- analyze$pars[2]
        Rho[idx,x] <- analyze$pars[3]
        hesseEP[idx,x] <- diag(ginv(analyze$hessian))[1]
        hesseEN[idx,x] <- diag(ginv(analyze$hessian))[2]
        hesseR[idx,x] <- diag(ginv(analyze$hessian))[3]
      }
    }
  }
  EpsilonP_mu <- mean(Epsilon_P[,x])
  EpsilonP_sigma <- sum(Epsilon_P[,x]^2 + hesseEP[,x])/n - EpsilonP_mu^2
  EpsilonN_mu <- mean(Epsilon_N[,x])
  EpsilonN_sigma <- sum(Epsilon_N[,x]^2 + hesseEN[,x])/n - EpsilonN_mu^2
  Rho_mu <- mean(Rho[,x])
  Rho_sigma <- sum(Rho[,x]^2 + hesseR[,x])/n - Rho_mu^2
  QEP <- -(n*log(2*pi*EpsilonP_sigma))/2-sum((Epsilon_P[,x]^2 + hesseEP[,x] - 2*Epsilon_P[,x]*EpsilonP_mu + EpsilonP_mu^2)/(2*EpsilonP_sigma))
  QEN <- -(n*log(2*pi*EpsilonN_sigma))/2-sum((Epsilon_N[,x]^2 + hesseEN[,x] - 2*Epsilon_N[,x]*EpsilonN_mu + EpsilonN_mu^2)/(2*EpsilonN_sigma))
  QR <- -(n*log(2*pi*Rho_sigma))/2-sum((Rho[,x]^2 + hesseR[,x] - 2*Rho[,x]*Rho_mu + Rho_mu^2)/(2*Rho_sigma))
  Q_value[x] <- QEP + QEN + QR
  if(abs(Q_value[x] - Q_value[x-1]) < 0.01) break
}

Ep_P <- 1/(1+exp(-Epsilon_P[,x]))
Ep_N <- 1/(1+exp(-Epsilon_N[,x]))
Rh <-exp(Rho[,x])

# calculate iBIC value
for (idx in 1:n){
  for (k in 1:1000){
    epsilonP_k <- rnorm(1,EpsilonP_mu,sqrt(EpsilonP_sigma))
    epsilonN_k <- rnorm(1,EpsilonN_mu,sqrt(EpsilonN_sigma))
    rho_k <- rnorm(1,Rho_mu,sqrt(Rho_sigma))
    sampling[idx,k] <- f_minimize(c(epsilonP_k,epsilonN_k,rho_k),choice_all[idx,],result_all[idx,],stimuli_all[idx,],trial[idx],s)
    if(is.nan(sampling[idx,k])){
      while(is.nan(sampling[idx,k])){
        epsilonP_k <- rnorm(1,EpsilonP_mu,sqrt(EpsilonP_sigma))
        epsilonN_k <- rnorm(1,EpsilonN_mu,sqrt(EpsilonN_sigma))
        rho_k <- rnorm(1,Rho_mu,sqrt(Rho_sigma))
        sampling[idx,k] <- f_minimize(c(epsilonP_k,epsilonN_k,rho_k),choice_all[idx,],result_all[idx,],stimuli_all[idx,],trial[idx],s)
      }
    }
    if(is.infinite(sampling[idx,k])){
      epsilonP_k <- rnorm(1,EpsilonP_mu,sqrt(EpsilonP_sigma))
      epsilonN_k <- rnorm(1,EpsilonN_mu,sqrt(EpsilonN_sigma))
      rho_k <- rnorm(1,Rho_mu,sqrt(Rho_sigma))
      sampling[idx,k] <- f_minimize(c(epsilonP_k,epsilonN_k,rho_k),choice_all[idx,],result_all[idx,],stimuli_all[idx,],trial[idx],s)
    }
  }
  E2_probability[idx] <- log(sum(exp(-sampling[idx,]))/1000)#log(mean(exp(-sampling[idx,])))
}

# The penalty term for the number of free parameter is twice the number of free parameters, because we used the mean and variance of each free parameter
iBIC_E2 <- -2*sum(E2_probability)+n_param*2*log(sum(trial))

saveworkspace = paste(subj_version,"_Ep2Rh1_learning.RData",sep = "")
save.image(file = saveworkspace) # save all workspace