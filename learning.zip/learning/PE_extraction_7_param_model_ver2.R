f_learn_PE = function(param,choice,result,stimuli,trial,n,s){
  epsilon_RP <- 1/(1+exp(-param[1]))
  epsilon_RN <- 1/(1+exp(-param[2]))
  epsilon_PP <- 1/(1+exp(-param[3]))
  epsilon_PN <- 1/(1+exp(-param[4]))
  rho <- exp(param[5])
  b <- param[6]
  pav <-exp(param[7])
  choice <- choice
  result <- result
  stimuli <- stimuli
  st <- result > 0 # return a boolean vector that represents the trial number where the reward is appeared.
  trial <- trial
  Pgo <- numeric(trial)
  PE <- numeric(trial)
  ll <- 0
  Q <- matrix(0, nrow = s*2, ncol = trial)
  V <- matrix(0, nrow = s, ncol = trial)
  for (t in 1:trial){
    Pgo[t] <- exp(Q[stimuli[t]+s,t]+pav*V[stimuli[t],t]+b)/(exp(Q[stimuli[t]+s,t]+pav*V[stimuli[t],t]+b) + exp(Q[stimuli[t],t]))
    ll <- ll + (choice[t] == s) * log(Pgo[t]) + (choice[t] == 0) * log(1-Pgo[t])
    PE[t] <- delta <- rho * result[t] - Q[stimuli[t]+choice[t],t]
    if (t < trial){
      Q[,t+1] <- Q[,t]
      V[,t+1] <- V[,t]
      if(any(st[stimuli == stimuli[t]])){#return true if the reward on a stimulus at trial t is appeared somewhere. 
        if(delta > 0){
          Q[stimuli[t]+choice[t],t+1]  <- Q[stimuli[t]+choice[t],t] + epsilon_RP * delta
          V[stimuli[t],t+1]  <- V[stimuli[t],t] + epsilon_RP * (rho * result[t] - V[stimuli[t],t])
        }
        else{
          Q[stimuli[t]+choice[t],t+1]  <- Q[stimuli[t]+choice[t],t] + epsilon_RN * delta
          V[stimuli[t],t+1]  <- V[stimuli[t],t] + epsilon_RN * (rho * result[t] - V[stimuli[t],t])
        }
      }
      else{
        if(delta > 0){
          Q[stimuli[t]+choice[t],t+1]  <- Q[stimuli[t]+choice[t],t] + epsilon_PP * delta
          V[stimuli[t],t+1]  <- V[stimuli[t],t] + epsilon_PP * (rho * result[t] - V[stimuli[t],t])
        }
        else{
          Q[stimuli[t]+choice[t],t+1]  <- Q[stimuli[t]+choice[t],t] + epsilon_PN * delta
          V[stimuli[t],t+1]  <- V[stimuli[t],t] + epsilon_PN * (rho * result[t] - V[stimuli[t],t])
        }
      }
    }
  }
  return(list(negll = -ll, Q = Q, Pgo = Pgo, PE = PE))
}

id <- 1;x <- 1 #show the PEs in the Subject #1
plot(f_learn_PE(c(Epsilon_RP[id,x],Epsilon_RN[id,x],Epsilon_PP[id,x],Epsilon_PN[id,x],Rho[id,x],Bias[id,x],Pavlov[id,x]),choice_all[id,],result_all[id,],stimuli_all[id,],trial[id],n,s)$PE,type = "l")

f_plot_PE = function(id,im,x = 1){#id = participants'ID; im = image, x = set the parameters in x th iteration in the EM-algorithm (x is set to 1 by default).
  pe <- f_learn_PE(c(Epsilon_RP[id,x],Epsilon_RN[id,x],Epsilon_PP[id,x],Epsilon_PN[id,x],Rho[id,x],Bias[id,x],Pavlov[id,x]),choice_all[id,],result_all[id,],stimuli_all[id,],trial[id],n,s)$PE
  c_I <- choice_all[id,1:trial[id]][stimuli_all[id,1:trial[id]] == im]/s*2*exp(Rho[id,x])-exp(Rho[id,x])
  r_I <- 1+abs(result_all[id,1:trial[id]][stimuli_all[id,1:trial[id]] == im])
  t_I <- 1:sum(stimuli_all[id,1:trial[id]]==im)
  plot(t_I,pe[stimuli_all[id,1:trial[id]]==im], type = "l",ylim = c(-exp(Rho[id,x]),exp(Rho[id,x])),xlab = "trial",ylab = "PE")
  par(new =T)
  plot(t_I,c_I,ylim = c(-exp(Rho[id,x]),exp(Rho[id,x])),col = r_I,ann = F)
}

#Please use this function for extracting the PE. The PE is output in the same format as the Pgo values.
f_learn_PE(c(Epsilon_RP[id,x],Epsilon_RN[id,x],Epsilon_PP[id,x],Epsilon_PN[id,x],Rho[id,x],Bias[id,x],Pavlov[id,x]),choice_all[id,],result_all[id,],stimuli_all[id,],trial[id],n,s)$PE
